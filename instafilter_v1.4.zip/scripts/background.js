// 1. Configura para abrir o Side Panel DIRETAMENTE ao clicar no ícone
async function configurarPainelDireto() {
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  console.log("Painel lateral configurado para acesso direto (Versão Gratuita).");
}

// 2. Executa essa configuração sempre que a extensão for instalada ou o Chrome abrir
chrome.runtime.onInstalled.addListener(configurarPainelDireto);
chrome.runtime.onStartup.addListener(configurarPainelDireto);

/* O código abaixo está COMENTADO para sua referência futura. 
  Ele não será executado pelo Chrome.
  
  chrome.action.onClicked.addListener(async (tab) => {
    // Antiga lógica de abrir popup de login...
  });
*/