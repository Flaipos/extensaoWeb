const inputsContainer = document.getElementById('inputs-container');
const btnAddInput = document.getElementById('btn-add-input');
const btnFilter = document.getElementById('btn-filter');
const resultsList = document.getElementById('results-list');

// --- NOVA FUNÇÃO AUXILIAR ---
// Garante que o script de extração seja injetado na página se ele não estiver lá
async function garantirScriptInjetado(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ["scripts/content.js"]
    });
  } catch (e) {
    console.log("Script já ativo ou erro na injeção:", e);
  }
}

let inputCount = 1;
btnAddInput.addEventListener('click', () => {
  // Alterado de 5 para 10
  if (inputCount < 10) { 
    inputCount++;
    const newInput = document.createElement('input');
    newInput.type = 'text';
    newInput.className = 'filter-input';
    newInput.placeholder = `Filtro ${inputCount}`;
    inputsContainer.appendChild(newInput);
  } else {
    // Mensagem de alerta atualizada para 10
    alert("Limite de 10 filtros atingido."); 
  }
});

// --- ONDE A MUDANÇA PRINCIPAL ACONTECE ---
btnFilter.addEventListener('click', async () => {
  const inputs = document.querySelectorAll('.filter-input');
  const keywords = Array.from(inputs).map(i => i.value.trim()).filter(k => k !== "");

  if (keywords.length === 0) return alert("Digite ao menos um filtro!");

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  // 1. VERIFICAÇÃO DE SITE (Se está no Instagram)
  if (!tab || !tab.url || !tab.url.includes("instagram.com")) {
    resultsList.innerHTML = `<div style="color: #ed4956; padding: 10px; text-align: center; border: 1px solid #ed4956; border-radius: 8px; background: #fff1f2;">
                                <strong>⚠️ Erro de Site</strong><br>Acesse o Instagram para filtrar.
                             </div>`;
    return;
  }

  // 2. NOVA VERIFICAÇÃO DE PUBLICAÇÃO (O "pulo do gato")
  // URLs de posts contêm "/p/", "/reels/" ou "/tv/"
  const ehPublicacao = tab.url.includes("/p/") || tab.url.includes("/reels/") || tab.url.includes("/tv/");
  
  if (!ehPublicacao) {
    resultsList.innerHTML = `<div style="color: #ed4956; padding: 10px; text-align: center; border: 1px solid #ed4956; border-radius: 8px; background: #fff1f2; font-size: 13px;">
                                <strong>⚠️ Publicação não encontrada</strong><br>
                                Por favor, abra uma foto ou um Reels para começar a filtrar os comentários.
                                Após abrir a postagem, certifique que carregou todos os comentários da publicação (clicando no sinal de '+' até que não apareça mais).
                             </div>`;
    return;
  }

  resultsList.innerHTML = "<li>Buscando...</li>";

  // Tenta enviar a mensagem para o Instagram
  chrome.tabs.sendMessage(tab.id, { action: "extract_comments", keywords }, async (response) => {
    if (chrome.runtime.lastError) {
      console.warn("Conexão perdida. Tentando injetar script e repetir...");
      await garantirScriptInjetado(tab.id);
      setTimeout(() => {
        chrome.tabs.sendMessage(tab.id, { action: "extract_comments", keywords }, (secondResponse) => {
          renderizarComentarios(secondResponse);
        });
      }, 500);
    } else {
      renderizarComentarios(response);
    }
  });
});

// --- FUNÇÃO PARA CRIAR A LISTA NA TELA (Para não repetir código) ---
function renderizarComentarios(response) {
  resultsList.innerHTML = "";
  
  if (response && response.comments) {
    let commentsToDisplay = response.comments;

    if (commentsToDisplay.length === 0) {
      resultsList.innerHTML = "<li>Nenhum comentário corresponde aos filtros.</li>";
      return;
    }

    commentsToDisplay.forEach(c => {
      const li = document.createElement('li');
      li.className = 'comment-item';
      li.style = "border-bottom: 1px solid #eee; padding: 12px; list-style: none; background: white; margin-bottom: 8px; border-radius: 8px;";
      
      li.innerHTML = `
        <div style="display: flex; align-items: center; gap: 8px;">
          <strong style="color:#00376b; cursor:pointer;" class="btn-profile">@${c.user}</strong>
        </div>
        <p style="margin:5px 0; font-size: 13px; color: #262626; word-break: break-word; white-space: pre-wrap;">${c.text}</p>
        ${c.meta ? `<div style="color: #8e8e8e; font-size: 11px; margin-bottom: 8px; font-weight: 600;">${c.meta}</div>` : ''}
        <button class="btn-locate" style="width: 100%; cursor:pointer; background:#0095f6; color:white; border:none; border-radius:4px; padding:8px; font-size:11px; font-weight:bold;">
          📍 LOCALIZAR COMENTÁRIO
        </button>
      `;

      li.querySelector('.btn-profile').addEventListener('click', () => {
          const cleanUser = c.user.replace('@', '').trim();
          window.open(`https://www.instagram.com/${cleanUser}/`, '_blank');
      });

      li.querySelector('.btn-locate').addEventListener('click', async () => {
        const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
        chrome.tabs.sendMessage(activeTab.id, { 
          action: "highlight_comment", 
          user: c.user, 
          text: c.text 
        });
      });

      resultsList.appendChild(li);
    });
  } else {
    resultsList.innerHTML = "<li>Nenhum comentário encontrado. Tente recarregar a página do Instagram.</li>";
  }
}

document.getElementById('btn-logout').addEventListener('click', () => {
    resultsList.innerHTML = "";
    alert("Filtros limpos!");
});